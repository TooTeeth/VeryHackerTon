export default function VpunkPage() {
  return <div className="flex justify-center items-center h-screen text-4xl">Comming Soon...</div>;
}
