import CharacterCreate from "../../../components/Vygdrasil/CharacterCreate";

export default function JobSelector() {
  return (
    <div>
      <CharacterCreate />
    </div>
  );
}
