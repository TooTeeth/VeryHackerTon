export default function ObfuscatePage() {
  return <div className="flex justify-center items-center h-screen text-4xl">Comming Soon...</div>;
}
