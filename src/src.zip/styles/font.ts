import { Baloo_Bhaina_2 } from "next/font/google";

export const baloo = Baloo_Bhaina_2({
  weight: ["400", "500", "600", "700", "800"],
  subsets: ["latin"],
  display: "swap",
});
